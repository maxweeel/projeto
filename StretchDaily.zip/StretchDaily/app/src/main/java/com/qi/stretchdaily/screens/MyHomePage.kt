package com.qi.stretchdaily.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.qi.stretchdaily.composables.Grid
import com.qi.stretchdaily.composables.MyBottomBar
import com.qi.stretchdaily.composables.MyTopBar
import com.qi.stretchdaily.composables.listImage
import com.qi.stretchdaily.ui.theme.StretchDailyTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyHomePage(
    modifier: Modifier = Modifier
) {
    Scaffold (
        topBar = { MyTopBar()},
        bottomBar = { MyBottomBar()},
         content = {
                    x -> Column (modifier = modifier.padding(x)){
                Grid(list = listImage)
            }

        }
    )
}

@Preview
@Composable
fun MyHomePagePrev() {
    StretchDailyTheme {
        MyHomePage()
    }
}