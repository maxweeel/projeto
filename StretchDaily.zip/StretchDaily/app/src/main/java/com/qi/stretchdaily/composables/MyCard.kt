package com.qi.stretchdaily.composables

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource

import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.qi.stretchdaily.R
import com.qi.stretchdaily.screens.MyHomePage
import com.qi.stretchdaily.ui.theme.StretchDailyTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyCards(
    modifier: Modifier = Modifier,
   @DrawableRes image: Int,
    onChangeScreen: (Int) -> Unit,
    index: Int
) {
   Card(
       modifier = modifier.padding(5.dp),
      content = {
         Column (modifier = modifier.padding(10.dp)){
               Image(
                   painter = painterResource(id = image),
                   contentDescription = null,
                   modifier = modifier
                       .fillMaxWidth()
                       .clickable { onChangeScreen(index) },
                   contentScale = ContentScale.FillWidth
               )
               Divider(
                   thickness = 1.dp,
                   modifier = modifier.padding(5.dp)
                )
              //  Switch(
                    //checked = checked,
                  //  onCheckedChange = onCheck
               // )

            }
        }
    )
}


@Composable
fun MyCardState(
    modifier: Modifier = Modifier,
                    @DrawableRes image: Int = R.drawable.manha) {
    var check by remember {
        mutableStateOf(false)
    }
    var index by remember {
        mutableStateOf (0)
    }


    MyCards(
        image = image,
       // checked = check,
      //  onCheck = { x -> check = x },
        onChangeScreen = {x -> index = x},
        index = index
    )
}



@Preview
@Composable
fun MyCardPrev() {
    MyCardState()

}