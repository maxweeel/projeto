package com.qi.stretchdaily.composables

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.qi.stretchdaily.ui.theme.StretchDailyTheme

@Composable
fun MyBottomBar(
    modifier: Modifier = Modifier
) {

   BottomAppBar (
       containerColor = Color(0xFFE67E75),
       contentColor =  Color(0xFFFFFFFF)
   ){
       Row (
           horizontalArrangement = Arrangement.SpaceBetween,
           modifier = modifier.fillMaxWidth()
       ){
       IconButton(onClick = { /*TODO*/ }) {
           Icon(
               imageVector = Icons.Filled.DateRange,
               contentDescription = null
           )
       }
       IconButton(onClick = { /*TODO*/ }) {
           Icon(
               imageVector = Icons.Outlined.Home,
               contentDescription = null
           )
       }
       IconButton(onClick = { /*TODO*/ }) {
           Icon(
               imageVector = Icons.Outlined.Person,
               contentDescription = null
           )
         }
      }
   }
}

@Preview
@Composable
fun MyBottomPrev() {
    StretchDailyTheme {
        MyBottomBar()
    }
}