package com.qi.stretchdaily.composables

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.qi.stretchdaily.R

@Composable
fun Grid(
    modifier: Modifier = Modifier,
    list: List<Int> = listImage
) {
    LazyColumn(
        contentPadding = PaddingValues(10.dp),
        content = {
            items(list) {
                MyCardState(image = it)
            }
        }
    )
}
val listImage = listOf(
    R.drawable.manha,
    R.drawable.tarde,
    R.drawable.noite
)


@Preview
@Composable
fun GridPrev() {
    Grid()
}